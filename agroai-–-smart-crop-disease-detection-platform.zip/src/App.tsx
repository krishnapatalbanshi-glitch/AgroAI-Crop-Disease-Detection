import React, { useState, useEffect, useRef, Component } from 'react';
import { 
  Upload, Leaf, ShieldCheck, Zap, Info, ChevronRight, AlertCircle, 
  CheckCircle2, LayoutDashboard, History, MessageSquare, Cloud, 
  LogOut, User as UserIcon, Menu, X, Send, Loader2, TrendingUp,
  Thermometer, Droplets
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  auth, db, googleProvider, OperationType, handleFirestoreError 
} from './lib/firebase';
import { 
  onAuthStateChanged, signInWithPopup, signOut, User 
} from 'firebase/auth';
import { 
  collection, query, where, orderBy, onSnapshot, addDoc, Timestamp, doc, setDoc 
} from 'firebase/firestore';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, PieChart, Pie, Cell 
} from 'recharts';
import { format } from 'date-fns';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { GoogleGenAI } from "@google/genai";

// --- Utilities ---

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const compressImage = (base64Str: string, maxWidth = 800, maxHeight = 800): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = base64Str;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > height) {
        if (width > maxWidth) {
          height *= maxWidth / width;
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width *= maxHeight / height;
          height = maxHeight;
        }
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', 0.7));
    };
  });
};

// --- Types ---
interface ScanResult {
  id?: string;
  userId: string;
  imageUrl: string;
  cropType: string;
  diseaseName: string;
  confidence: number;
  severity: 'Low' | 'Medium' | 'High';
  treatment: string;
  prevention: string;
  timestamp: any;
}

interface WeatherData {
  main: { temp: number; humidity: number };
  weather: { main: string; description: string }[];
  name: string;
  risk: string;
}

// --- Components ---

const GlassCard = ({ children, className, delay = 0 }: { children: React.ReactNode, className?: string, delay?: number, key?: React.Key }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay }}
    className={cn("bg-white/80 backdrop-blur-lg border border-white/20 shadow-xl rounded-3xl p-6", className)}
  >
    {children}
  </motion.div>
);

const Button = ({ children, onClick, disabled, variant = 'primary', className }: any) => {
  const variants = {
    primary: 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-200',
    secondary: 'bg-white text-emerald-900 border border-emerald-100 hover:bg-emerald-50 shadow-stone-100',
    ghost: 'bg-transparent text-emerald-700 hover:bg-emerald-50',
    danger: 'bg-red-500 text-white hover:bg-red-600 shadow-red-100'
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "px-6 py-3 rounded-xl font-bold transition-all duration-300 flex items-center justify-center gap-2 shadow-lg active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed",
        variants[variant as keyof typeof variants],
        className
      )}
    >
      {children}
    </button>
  );
};

// --- Main App ---

export default function App() {
  return (
    <AgroAIApp />
  );
}

function AgroAIApp() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'home' | 'dashboard' | 'detect' | 'history'>('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scans, setScans] = useState<ScanResult[]>([]);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [isChatOpen, setIsChatOpen] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
      if (u) {
        // Sync user to firestore
        const userRef = doc(db, 'users', u.uid);
        setDoc(userRef, {
          uid: u.uid,
          email: u.email,
          displayName: u.displayName,
          photoURL: u.photoURL,
          createdAt: Timestamp.now(),
          role: 'farmer'
        }, { merge: true });

        // Subscribe to scans
        const q = query(
          collection(db, 'scans'), 
          where('userId', '==', u.uid),
          orderBy('timestamp', 'desc')
        );
        
        return onSnapshot(q, (snapshot) => {
          const scanData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ScanResult));
          setScans(scanData);
        }, (err) => handleFirestoreError(err, OperationType.LIST, 'scans'));
      }
    });

    // Fetch weather
    fetch('/api/weather').then(res => res.json()).then(setWeather);

    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  const handleLogout = () => signOut(auth);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-emerald-50">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
        >
          <Leaf className="w-12 h-12 text-emerald-600" />
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-stone-200 py-4 px-6 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView('home')}>
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-200">
              <Leaf className="text-white w-6 h-6" />
            </div>
            <span className="text-2xl font-black tracking-tighter text-emerald-900">AgroAI</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <nav className="flex gap-6 text-sm font-bold text-stone-500">
              <button onClick={() => setView('home')} className={cn("hover:text-emerald-600", view === 'home' && "text-emerald-600")}>Home</button>
              {user && (
                <>
                  <button onClick={() => setView('dashboard')} className={cn("hover:text-emerald-600", view === 'dashboard' && "text-emerald-600")}>Dashboard</button>
                  <button onClick={() => setView('detect')} className={cn("hover:text-emerald-600", view === 'detect' && "text-emerald-600")}>Detect</button>
                  <button onClick={() => setView('history')} className={cn("hover:text-emerald-600", view === 'history' && "text-emerald-600")}>History</button>
                </>
              )}
            </nav>
            {user ? (
              <div className="flex items-center gap-4 border-l border-stone-200 pl-8">
                <div className="flex items-center gap-2">
                  <img src={user.photoURL || ''} className="w-8 h-8 rounded-full border border-emerald-100" alt="Avatar" />
                  <span className="text-sm font-bold text-stone-700">{user.displayName?.split(' ')[0]}</span>
                </div>
                <button onClick={handleLogout} className="text-stone-400 hover:text-red-500 transition-colors">
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <Button onClick={handleLogin}>Get Started</Button>
            )}
          </div>

          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-stone-200 overflow-hidden"
          >
            <div className="p-6 flex flex-col gap-4 font-bold text-stone-600">
              <button onClick={() => { setView('home'); setIsMenuOpen(false); }}>Home</button>
              {user && (
                <>
                  <button onClick={() => { setView('dashboard'); setIsMenuOpen(false); }}>Dashboard</button>
                  <button onClick={() => { setView('detect'); setIsMenuOpen(false); }}>Detect</button>
                  <button onClick={() => { setView('history'); setIsMenuOpen(false); }}>History</button>
                  <button onClick={handleLogout} className="text-red-500 text-left">Logout</button>
                </>
              )}
              {!user && <Button onClick={handleLogin}>Login</Button>}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Views */}
      <main className="max-w-7xl mx-auto px-6 py-12">
        {view === 'home' && <HomeView onStart={() => user ? setView('detect') : handleLogin()} />}
        {view === 'dashboard' && user && <DashboardView scans={scans} weather={weather} />}
        {view === 'detect' && user && <DetectView user={user} />}
        {view === 'history' && user && <HistoryView scans={scans} />}
      </main>

      {/* Chatbot */}
      {user && <Chatbot isChatOpen={isChatOpen} setIsChatOpen={setIsChatOpen} />}

      {/* Footer */}
      <footer className="bg-white border-t border-stone-200 py-12 px-6 mt-20">
        <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-12">
          <div className="col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Leaf className="text-emerald-600 w-6 h-6" />
              <span className="text-xl font-black text-emerald-900">AgroAI</span>
            </div>
            <p className="text-stone-500 max-w-sm">
              Revolutionizing agriculture through AI-powered disease detection and real-time farmer support.
            </p>
          </div>
          <div>
            <h4 className="font-bold text-stone-900 mb-4">Platform</h4>
            <nav className="flex flex-col gap-2 text-sm text-stone-500">
              <button onClick={() => setView('home')}>Home</button>
              <button onClick={() => setView('dashboard')}>Dashboard</button>
              <button onClick={() => setView('detect')}>Detection</button>
            </nav>
          </div>
          <div>
            <h4 className="font-bold text-stone-900 mb-4">Support</h4>
            <nav className="flex flex-col gap-2 text-sm text-stone-500">
              <a href="#">Help Center</a>
              <a href="#">Contact Us</a>
              <a href="#">Privacy Policy</a>
            </nav>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-stone-100 text-center text-sm text-stone-400">
          © 2026 AgroAI – Hackathon Project. All rights reserved.
        </div>
      </footer>
    </div>
  );
}

// --- View Components ---

const HomeView = ({ onStart }: { onStart: () => void }) => (
  <div className="space-y-32">
    <section className="grid md:grid-cols-2 gap-12 items-center">
      <div className="space-y-8">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-700 rounded-full text-xs font-black uppercase tracking-widest"
        >
          <Zap className="w-4 h-4" />
          AI-Powered Agriculture
        </motion.div>
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-6xl md:text-8xl font-black text-emerald-950 leading-[0.9] tracking-tighter"
        >
          Smart Crop <br />
          <span className="text-emerald-600">Protection.</span>
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-xl text-stone-500 max-w-md leading-relaxed"
        >
          Detect plant diseases instantly with our advanced AI. Protect your yields and optimize your farm's health.
        </motion.p>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex gap-4"
        >
          <Button onClick={onStart} className="px-10 py-5 text-lg">Start Detection</Button>
          <Button variant="secondary" className="px-10 py-5 text-lg">Learn More</Button>
        </motion.div>
      </div>
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative"
      >
        <div className="absolute -inset-4 bg-emerald-200/50 blur-3xl rounded-full" />
        <img 
          src="https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?auto=format&fit=crop&q=80&w=1000" 
          className="relative rounded-[40px] shadow-2xl border-8 border-white"
          alt="Farm"
        />
        <GlassCard className="absolute -bottom-8 -left-8 max-w-[200px] p-4 text-center">
          <div className="text-3xl font-black text-emerald-600">98%</div>
          <div className="text-xs font-bold text-stone-500 uppercase tracking-widest">Accuracy Rate</div>
        </GlassCard>
      </motion.div>
    </section>

    <section className="grid md:grid-cols-3 gap-8">
      {[
        { title: "Instant Diagnosis", desc: "Upload a photo and get results in under 2 seconds.", icon: Zap },
        { title: "Treatment Plans", desc: "Get expert-verified treatment and prevention advice.", icon: ShieldCheck },
        { title: "Health Analytics", desc: "Track your farm's health over time with visual data.", icon: TrendingUp }
      ].map((feature, i) => (
        <GlassCard key={i} delay={i * 0.1}>
          <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mb-6">
            <feature.icon className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-emerald-900 mb-2">{feature.title}</h3>
          <p className="text-stone-500 text-sm leading-relaxed">{feature.desc}</p>
        </GlassCard>
      ))}
    </section>
  </div>
);

const DashboardView = ({ scans, weather }: { scans: ScanResult[], weather: WeatherData | null }) => {
  const stats = [
    { label: "Total Scans", value: scans.length, icon: History, color: 'text-blue-600' },
    { label: "Healthy Crops", value: scans.filter(s => s.diseaseName.toLowerCase().includes('healthy')).length, icon: CheckCircle2, color: 'text-emerald-600' },
    { label: "Detected Issues", value: scans.filter(s => !s.diseaseName.toLowerCase().includes('healthy')).length, icon: AlertCircle, color: 'text-amber-600' },
  ];

  const chartData = scans.slice(0, 7).reverse().map(s => ({
    date: format(s.timestamp.toDate(), 'MMM dd'),
    confidence: s.confidence
  }));

  const diseaseDistribution = [
    { name: 'Healthy', value: scans.filter(s => s.diseaseName.toLowerCase().includes('healthy')).length },
    { name: 'Diseased', value: scans.filter(s => !s.diseaseName.toLowerCase().includes('healthy')).length },
  ];

  const COLORS = ['#10b981', '#f59e0b'];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-black text-emerald-950 tracking-tight">Farmer Dashboard</h2>
          <p className="text-stone-500">Real-time overview of your farm's health.</p>
        </div>
        {weather && (
          <GlassCard className="p-4 flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
                <Thermometer className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-bold text-stone-400 uppercase tracking-widest text-[10px]">Temp</div>
                <div className="font-black text-stone-800">{weather.main.temp}°C</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
                <Droplets className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-bold text-stone-400 uppercase tracking-widest text-[10px]">Humidity</div>
                <div className="font-black text-stone-800">{weather.main.humidity}%</div>
              </div>
            </div>
          </GlassCard>
        )}
      </div>

      {weather?.risk && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-amber-50 border border-amber-200 p-4 rounded-2xl flex items-center gap-4 text-amber-800"
        >
          <AlertCircle className="w-6 h-6 flex-shrink-0" />
          <div>
            <span className="font-black uppercase text-xs tracking-widest mr-2">Weather Alert:</span>
            <span className="text-sm font-medium">{weather.risk}</span>
          </div>
        </motion.div>
      )}

      <div className="grid md:grid-cols-3 gap-6">
        {stats.map((stat, i) => (
          <GlassCard key={i} className="flex items-center gap-6">
            <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center bg-stone-50", stat.color)}>
              <stat.icon className="w-7 h-7" />
            </div>
            <div>
              <div className="text-xs font-black text-stone-400 uppercase tracking-widest">{stat.label}</div>
              <div className="text-3xl font-black text-stone-900">{stat.value}</div>
            </div>
          </GlassCard>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <GlassCard className="h-[400px]">
          <h3 className="text-lg font-bold text-emerald-900 mb-6">Scan Confidence Trend</h3>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
              <Tooltip 
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              />
              <Line type="monotone" dataKey="confidence" stroke="#10b981" strokeWidth={4} dot={{ r: 6, fill: '#10b981', strokeWidth: 2, stroke: '#fff' }} activeDot={{ r: 8 }} />
            </LineChart>
          </ResponsiveContainer>
        </GlassCard>

        <GlassCard className="h-[400px]">
          <h3 className="text-lg font-bold text-emerald-900 mb-6">Crop Health Distribution</h3>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={diseaseDistribution}
                cx="50%"
                cy="50%"
                innerRadius={80}
                outerRadius={120}
                paddingAngle={5}
                dataKey="value"
              >
                {diseaseDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex justify-center gap-8 mt-4">
            {diseaseDistribution.map((d, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                <span className="text-xs font-bold text-stone-500 uppercase tracking-widest">{d.name}</span>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};

const DetectView = ({ user }: { user: User }) => {
  const [image, setImage] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setError(null);
      const reader = new FileReader();
      reader.onload = async (ev) => {
        const base64 = ev.target?.result as string;
        const compressed = await compressImage(base64);
        setImage(compressed);
      };
      reader.readAsDataURL(file);
      setResult(null);
    }
  };

  const runDetection = async () => {
    if (!image) return;
    setAnalyzing(true);
    setError(null);
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === "undefined" || apiKey === "null" || apiKey === "") {
        throw new Error("AI service temporarily unavailable. API key is not properly configured in the environment.");
      }

      const ai = new GoogleGenAI({ apiKey });
      const model = "gemini-3-flash-preview";
      const prompt = `Analyze this agricultural leaf image for diseases.
      
      SUPPORTED CROP CATEGORIES:
      - Vegetables: Tomato, Potato, Onion, Chili, Cabbage, Cauliflower, Brinjal (Eggplant), Carrot, Cucumber, Spinach, Peas.
      - Fruits: Apple, Grape, Mango, Banana, Orange, Papaya, Pomegranate, Guava, Strawberry.
      - Grains/Cereals: Rice, Wheat, Maize (Corn), Barley, Millet.
      - Cash Crops: Cotton, Sugarcane, Coffee, Tea, Rubber.
      - Pulses/Legumes: Soybean, Groundnut (Peanut), Lentil, Chickpea, Green gram, Black gram.

      DISEASE TYPES TO DETECT:
      Leaf Spot, Powdery Mildew, Early Blight, Late Blight, Rust Disease, Bacterial Spot, Mosaic Virus, Anthracnose, Black Rot, Downy Mildew, Wilt Disease, Root Rot, Scab Disease, Healthy Plant.
      
      Identify the crop and the disease if any. Provide specific treatment and prevention advice.
      
      Return JSON format: 
      { 
        "cropType": "Crop Name",
        "name": "Disease Name or 'Healthy'", 
        "confidence": 0-100, 
        "severity": "Low" | "Medium" | "High",
        "treatment": "Detailed treatment advice",
        "prevention": "Prevention tips for the future"
      }`;

      const imagePart = {
        inlineData: {
          mimeType: "image/jpeg",
          data: image.split(',')[1],
        },
      };

      const response = await ai.models.generateContent({
        model,
        contents: [{ parts: [{ text: prompt }, imagePart] }],
        config: { responseMimeType: "application/json" }
      });

      const text = response.text || "{}";
      const cleanText = text.replace(/```json\n?|```/g, "").trim();
      const data = JSON.parse(cleanText);
      
      const scanData: ScanResult = {
        userId: user.uid,
        imageUrl: image,
        cropType: data.cropType || 'Unknown',
        diseaseName: data.name || 'Unknown',
        confidence: data.confidence || 0,
        severity: data.severity || 'Low',
        treatment: data.treatment || 'No treatment advice available.',
        prevention: data.prevention || 'No prevention advice available.',
        timestamp: Timestamp.now()
      };

      await addDoc(collection(db, 'scans'), scanData);
      setResult(scanData);
    } catch (err: any) {
      console.error("Detection failed:", err);
      const message = err.message?.includes("API key") 
        ? "AI service temporarily unavailable. Please check your API key configuration."
        : "AI service temporarily unavailable. Please try again later.";
      setError(message);
    } finally {
      setAnalyzing(false);
    }
  };

  const severityColors = {
    Low: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    Medium: 'bg-amber-100 text-amber-700 border-amber-200',
    High: 'bg-red-100 text-red-700 border-red-200'
  };

  return (
    <div className="max-w-5xl mx-auto space-y-12">
      <div className="text-center space-y-4">
        <h2 className="text-5xl font-black text-emerald-950 tracking-tighter">AI Disease Detector</h2>
        <p className="text-stone-500 max-w-md mx-auto">Upload a leaf photo for instant diagnosis across 40+ crop varieties including Vegetables, Fruits, Grains, and Cash Crops.</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8 items-start">
        <GlassCard className="space-y-6">
          <div 
            onClick={() => fileRef.current?.click()}
            className={cn(
              "relative aspect-square rounded-3xl border-4 border-dashed transition-all duration-500 flex flex-col items-center justify-center cursor-pointer overflow-hidden",
              image ? "border-emerald-500 bg-emerald-50" : "border-stone-200 hover:border-emerald-400 hover:bg-stone-50"
            )}
          >
            {image ? (
              <img src={image} className="w-full h-full object-cover" alt="Upload" />
            ) : (
              <>
                <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-4 shadow-lg shadow-emerald-100">
                  <Upload className="w-10 h-10" />
                </div>
                <p className="font-bold text-stone-500">Tap to upload leaf photo</p>
                <p className="text-xs text-stone-400 mt-2 uppercase tracking-widest font-black text-center px-4">Optimized for 40+ Crops: Vegetables, Fruits, Grains, Cash Crops & Pulses</p>
              </>
            )}
            <input type="file" ref={fileRef} onChange={handleUpload} className="hidden" accept="image/*" />
          </div>

          <Button 
            onClick={runDetection} 
            disabled={!image || analyzing} 
            className="w-full py-5 text-lg"
          >
            {analyzing ? (
              <>
                <Loader2 className="w-6 h-6 animate-spin" />
                Fast AI Analysis...
              </>
            ) : (
              <>
                <Zap className="w-6 h-6" />
                Run AI Diagnosis
              </>
            )}
          </Button>
        </GlassCard>

        <AnimatePresence mode="wait">
          {error ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="h-full flex flex-col items-center justify-center p-8 bg-red-50 border-2 border-red-100 rounded-3xl text-center space-y-4"
            >
              <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center">
                <AlertCircle className="w-8 h-8" />
              </div>
              <div className="space-y-2">
                <h4 className="text-xl font-black text-red-900">Detection Error</h4>
                <p className="text-red-700 text-sm">{error}</p>
              </div>
              <Button variant="danger" onClick={() => setError(null)}>Try Again</Button>
            </motion.div>
          ) : result ? (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <GlassCard className="space-y-8 border-emerald-200 bg-emerald-50/50">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="px-2 py-1 bg-white rounded-lg text-[10px] font-black text-emerald-600 uppercase tracking-widest border border-emerald-100">{result.cropType}</span>
                      <span className={cn("px-2 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border", severityColors[result.severity])}>
                        {result.severity} Severity
                      </span>
                    </div>
                    <h3 className="text-4xl font-black text-emerald-950 leading-none">{result.diseaseName}</h3>
                  </div>
                  <div className="bg-white px-4 py-2 rounded-2xl shadow-sm border border-emerald-100 text-center">
                    <div className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Confidence</div>
                    <div className="text-xl font-black text-emerald-600">{result.confidence}%</div>
                  </div>
                </div>

                <div className="grid gap-4">
                  <div className="bg-white/60 p-5 rounded-2xl border border-white/40 space-y-3">
                    <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
                      <ShieldCheck className="w-5 h-5 text-emerald-600" />
                      Treatment Recommendation
                    </div>
                    <p className="text-stone-600 text-sm leading-relaxed">{result.treatment}</p>
                  </div>

                  <div className="bg-white/60 p-5 rounded-2xl border border-white/40 space-y-3">
                    <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
                      <Info className="w-5 h-5 text-emerald-600" />
                      Prevention Advice
                    </div>
                    <p className="text-stone-600 text-sm leading-relaxed">{result.prevention}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-4 bg-emerald-100/50 rounded-2xl text-emerald-800">
                  <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                  <p className="text-xs font-bold">Scan saved to history. You can access this anytime from your dashboard.</p>
                </div>
              </GlassCard>
            </motion.div>
          ) : analyzing ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="h-full flex flex-col items-center justify-center p-12 text-center space-y-6"
            >
              <div className="relative">
                <motion.div 
                  animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="absolute inset-0 bg-emerald-400 blur-2xl rounded-full"
                />
                <Loader2 className="w-16 h-16 text-emerald-600 animate-spin relative z-10" />
              </div>
              <div className="space-y-2">
                <h4 className="text-xl font-black text-emerald-900">Processing Image</h4>
                <p className="text-stone-500 text-sm">Our AI is identifying the crop and analyzing leaf patterns...</p>
              </div>
            </motion.div>
          ) : (
            <div className="h-full flex items-center justify-center p-12 border-2 border-dashed border-stone-200 rounded-3xl text-stone-400">
              <div className="text-center space-y-4">
                <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center mx-auto">
                  <Zap className="w-8 h-8" />
                </div>
                <p className="font-bold">Results will appear here after analysis</p>
              </div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

const HistoryView = ({ scans }: { scans: ScanResult[] }) => {
  const severityColors = {
    Low: 'bg-emerald-100 text-emerald-700',
    Medium: 'bg-amber-100 text-amber-700',
    High: 'bg-red-100 text-red-700'
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-black text-emerald-950 tracking-tight">Scan History</h2>
        <p className="text-stone-500">Review your past crop health assessments.</p>
      </div>

      <div className="grid gap-4">
        {scans.length > 0 ? scans.map((scan, i) => (
          <motion.div 
            key={scan.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <GlassCard className="flex items-center gap-6 p-4">
              <img src={scan.imageUrl} className="w-20 h-20 rounded-2xl object-cover border border-stone-100" alt="Scan" />
              <div className="flex-1">
                <div className="flex justify-between items-start mb-1">
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100">{scan.cropType}</span>
                      <span className={cn("text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded-md", severityColors[scan.severity])}>{scan.severity}</span>
                    </div>
                    <h4 className="font-black text-emerald-900 text-lg">{scan.diseaseName}</h4>
                  </div>
                  <span className="text-[10px] font-black text-stone-400 uppercase tracking-widest">
                    {format(scan.timestamp.toDate(), 'MMM dd, yyyy • HH:mm')}
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1 text-xs font-bold text-stone-500">
                    <Zap className="w-3 h-3 text-emerald-500" />
                    {scan.confidence}% Confidence
                  </div>
                  <div className="h-1 w-24 bg-stone-100 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500" style={{ width: `${scan.confidence}%` }} />
                  </div>
                </div>
              </div>
              <Button variant="ghost" className="p-2">
                <ChevronRight className="w-5 h-5" />
              </Button>
            </GlassCard>
          </motion.div>
        )) : (
        <div className="text-center py-20 text-stone-400 font-bold">No scans found. Start your first detection!</div>
      )}
    </div>
  </div>
);
};

const Chatbot = ({ isChatOpen, setIsChatOpen }: any) => {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([
    { role: 'ai', text: 'Hello! I am your AgroAI Assistant. How can I help you with your crops today?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === "undefined" || apiKey === "null" || apiKey === "") {
        throw new Error("AI service temporarily unavailable. API key is not properly configured in the environment.");
      }

      const ai = new GoogleGenAI({ apiKey });
      const chat = ai.chats.create({
        model: "gemini-3-flash-preview",
        config: {
          systemInstruction: "You are an expert AI Farmer Assistant. You specialize in detecting and treating diseases for a wide variety of crops including Vegetables, Fruits, Grains, Cash Crops, and Pulses. Provide detailed treatment plans, prevention tips, and general farming advice. Be concise, professional, and helpful.",
        },
      });

      const response = await chat.sendMessage({ message: userMsg });
      setMessages(prev => [...prev, { role: 'ai', text: response.text }]);
    } catch (error: any) {
      console.error("Chat failed:", error);
      const message = error.message?.includes("API key") 
        ? "AI service temporarily unavailable. Please check your API key configuration."
        : "I'm sorry, I'm having trouble connecting right now. Please try again later.";
      setMessages(prev => [...prev, { role: 'ai', text: message }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-[100]">
      <AnimatePresence>
        {isChatOpen && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="absolute bottom-20 right-0 w-[350px] md:w-[400px] h-[500px] bg-white rounded-[32px] shadow-2xl border border-stone-200 flex flex-col overflow-hidden"
          >
            <div className="bg-emerald-600 p-6 text-white flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-black text-lg leading-none">AgroAI Assistant</div>
                  <div className="text-[10px] uppercase font-bold tracking-widest opacity-60">Online • Expert System</div>
                </div>
              </div>
              <button onClick={() => setIsChatOpen(false)} className="hover:bg-white/10 p-2 rounded-lg transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div ref={scrollRef} className="flex-1 p-6 overflow-y-auto space-y-4 bg-stone-50/50">
              {messages.map((m, i) => (
                <div key={i} className={cn("flex", m.role === 'user' ? "justify-end" : "justify-start")}>
                  <div className={cn(
                    "max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed",
                    m.role === 'user' ? "bg-emerald-600 text-white rounded-tr-none" : "bg-white text-stone-700 border border-stone-200 rounded-tl-none shadow-sm"
                  )}>
                    {m.text}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-white p-4 rounded-2xl border border-stone-200 rounded-tl-none shadow-sm">
                    <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 bg-white border-t border-stone-100 flex gap-2">
              <input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask about crop diseases..."
                className="flex-1 bg-stone-100 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500 transition-all"
              />
              <button 
                onClick={handleSend}
                className="w-12 h-12 bg-emerald-600 text-white rounded-xl flex items-center justify-center hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-100"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button 
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsChatOpen(!isChatOpen)}
        className="w-16 h-16 bg-emerald-600 text-white rounded-2xl flex items-center justify-center shadow-2xl shadow-emerald-200 relative"
      >
        {isChatOpen ? <X className="w-8 h-8" /> : <MessageSquare className="w-8 h-8" />}
        {!isChatOpen && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white" />
        )}
      </motion.button>
    </div>
  );
};
